from django.apps import AppConfig


class MounibappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mounibapp'
